/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package knapsack;

import java.util.ArrayList;
import java.util.List;

/**
 * Utilizando a solução do problema da Mochila (Knapsack)
 * Conseguimos indicar quais são os melhores comerciais para serem exibidos
 * no tempo que nos é determinado.
 * Com esse algoritmo asseguramos que a emissora irá apresentar conseguir lucrar o máximo com o tempo disponível nos comerciais.
 * 
 * @author 
 */
public class Knapsack {
    
    
    public static List<Advertisement> getAds(List<Advertisement> allAvailableAds, int durationLimit) {
        boolean[][] keep = prepareAdsToPick(allAvailableAds, durationLimit);
        
        List<Advertisement> selectedItens = new ArrayList<Advertisement>();
        int K = durationLimit;
        int n = allAvailableAds.size();
        for (int i = n - 1; i >= 0; i--) { 
            if (keep[i][K]) {
                Advertisement selectedItem = allAvailableAds.get(i);
                selectedItens.add(selectedItem);
                K = K - selectedItem.getDuration();

            }
        }

        return selectedItens;
    }
 
    private static boolean[][] prepareAdsToPick(List<Advertisement> itens, int durationLimit) {
        int nItems = itens.size();
        int[][] dpTable = new int[nItems + 1][durationLimit + 1];
        boolean[][] keep = new boolean[nItems][durationLimit + 1];
        for (int i = 1; i <= nItems; i++) {
            
            for (int w = 1; w <= durationLimit; w++) {
                if (itens.get(i - 1).getDuration() > w) {
                    dpTable[i][w] = dpTable[i - 1][w];
                } else {
                    int pYes = itens.get(i - 1).getValue() + dpTable[i - 1][w - itens.get(i - 1).getDuration()];
                    int pNo = dpTable[i - 1][w];
                    if (pYes > pNo) {
                        keep[i - 1][w] = true;
                        dpTable[i][w] = pYes;
                    } else {
                        dpTable[i][w] = pNo;
                    }
                }
            }
        }
        
        return keep;
    }
    
}
