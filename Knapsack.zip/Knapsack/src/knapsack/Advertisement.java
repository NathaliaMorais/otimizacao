package knapsack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javafx.print.Collation;

/**
 * Entidade que representa uma propaganda. Possui o nome da marca, descrição da
 * propaganda, duração(em minutos) e valor(de 1 a 10 indica o quão rentável essa
 * propaganda é para a TV).
 *
 * @author
 */
public class Advertisement implements Comparable<Advertisement> {

    private String brand;
    private String description;
    private int duration;
    private int value;

    public Advertisement(String brand, String description, int duration, int value) {
        this.brand = brand;
        this.description = description;
        this.duration = duration;
        this.value = value;
    }
    
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
    
    public static List<Advertisement> createDefaultAdvertisements() {
         List<Advertisement> ads = new ArrayList<Advertisement>();
         ads.add(new Advertisement("Coca-cola", "Comercial de Natal", 1, 1));
         ads.add(new Advertisement("Dove", "Nova linha de shampoo", 3, 4));
         ads.add(new Advertisement("Netflix", "Promoção nova série", 4, 5));
         ads.add(new Advertisement("Visa Card", "Anúncio cartão premium", 5, 7));
         
         
         ads.add(new Advertisement("Vilma Alimentos", "Novas sobremesas.", 4, 1));
         ads.add(new Advertisement("Elmo Calçados", "Calçados em promoção", 5, 4));
         ads.add(new Advertisement("Cotemig", "Ensino de qualidade", 8, 7));
         ads.add(new Advertisement("Apple", "Tecnologia de ponta", 9, 9));
         
         Collections.sort(ads);
         
         return ads;
    }
        

    @Override
    public int compareTo(Advertisement o) {
        if (duration == o.getDuration()) {
            return compareValueTo(o);
        } else if (duration > o.getDuration()) {
            return 1;
        } else {
            return -1;
        }
    }

    public int compareValueTo(Advertisement o) {
        if (value == o.value) {
            return 0;
        } else if (value > o.value) {
            return 1;
        } else {
            return -1;
        }
    }

    @Override
    public String toString() {
        
        return "<html> <p><b>" + brand + "</b></p> Duração: " + duration + "<BR> Valor: " + value + "<BR> <BR> </html>";
    }
    
}
